<?php 

$conex = mysqli_connect("localhost","root","","empresa");

$id_bodega = $_POST["id_bodega"];
$nombre_bodega = $_POST["nombre_bodega"];
$stock_bodega = $_POST["stock_bodega"];
$direccion_bodega =  $_POST["direccion_bodega"];

$sql_update = "UPDATE `bodega` SET `nombre_bodega` = '$nombre_bodega', `stock_bodega` ='$stock_bodega', `direccion` ='$direccion_bodega'  WHERE `bodega`.`id_bodega` = $id_bodega;";
$resp = mysqli_query($conex, $sql_update);

if($resp){
	
	echo "<script> alert('Bodega editada con éxito..');</script>";
	
	mysqli_close($conex);
	$url='editar_bodega.php?id_bodega='.$id_bodega;
	echo '<meta http-equiv=refresh content="0.2; '.$url.'">';
	die;
	
	
}

?>