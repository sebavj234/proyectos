<?php 

$conex = mysqli_connect("localhost","root","","empresa");
$id_bodega = $_POST['id_bodega'];

$deleteQuery = "DELETE FROM bodega WHERE id_bodega=".$id_bodega;
$respuesta = mysqli_query($conex, $deleteQuery);

if($respuesta){
	echo "Bodega a sido borrada correctamente!";
}

?>