<?php 

if($_POST){
	
	$conex = mysqli_connect("localhost","root","","empresa");
	
	$nombre_bodega = $_POST["nombre_bodega"];
	$bodega_stock = $_POST["stock_bodega"];
	$direc_bodega = $_POST["direc_bodega"];
	
	$sql = "INSERT INTO `bodega` (`id_bodega`, `nombre_bodega`, `stock_bodega`, `direccion`) VALUES (NULL,'".$nombre_bodega."','".$bodega_stock."','".$direc_bodega."');";
	$resp = mysqli_query($conex, $sql);
	
	echo "<script> alert('Bodega nueva ingresada con éxito..');</script>";
	
	mysqli_close($conex);
	$url='ingresar_bodega.php';
	echo '<meta http-equiv=refresh content="0.2; '.$url.'">';
	die;
	
	
}

?>