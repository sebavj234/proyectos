<?php
$conex = mysqli_connect("localhost","root","","empresa");
$id_producto = $_POST['id_producto'];

$deleteQuery = "DELETE FROM producto WHERE id_producto=".$id_producto;
$respuesta = mysqli_query($conex, $deleteQuery);

if($respuesta){
	echo "El producto ha sido eliminado correctamente!";
}




?>