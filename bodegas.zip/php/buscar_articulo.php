<?php
$conex = mysqli_connect("localhost","root","","empresa");

if($_POST["detalle_articulo"]=="" || $_POST["stock"]==""){
	echo "Debe completar los campos solicitados.";
}
else if($_POST["detalle_articulo"]==null || $_POST["stock"]==null){
	echo "Debe completar los campos solicitados.";
}else{

$sql = "SELECT *  FROM `articulo` WHERE `detalle_articulo` LIKE '%".$_POST["detalle_articulo"]."%' AND `stock_articulo` = ".$_POST["stock"].";";
$respuesta = mysqli_query($conex,$sql);

while($row = mysqli_fetch_array($respuesta)){
	
	$articulo = $row["nombre_articulo"];
	$articulo_detalle = $row["detalle_articulo"];
	$stock_articulo = $row["stock_articulo"];
	
}

if(mysqli_num_rows($respuesta) > 0){
	echo "<div class='col-8'>";
	echo "<br>";
	echo "Resultado:";
	echo "<br>";
	echo "Articulo: ".$articulo;
    echo "<br>";
    echo "Detalle: ".$articulo_detalle;
    echo "<br>";
    echo "Stock: ".$stock_articulo;
	echo "</div>";
	
}else{
	echo "<div class='col-8'>";
	echo "Busqueda sin resultados..";
	echo "</div>";
}

}



?>