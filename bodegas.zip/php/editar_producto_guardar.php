<?php 

$conex = mysqli_connect("localhost","root","","empresa");

$id_producto = $_POST["id_producto"];
$nuevo_producto = $_POST["nombre_producto"];
$nueva_bodega =  $_POST["bodega_producto"];

$sql_update = "UPDATE `producto` SET `nombre_producto` = '$nuevo_producto', `id_bodega_fk` ='$nueva_bodega' WHERE `producto`.`id_producto` = $id_producto;";
$resp = mysqli_query($conex, $sql_update);

if($resp){
	
	echo "<script> alert('Producto actual a sido editado con éxito..');</script>";
	
	mysqli_close($conex);
	$url='editar_producto.php?id_prod='.$id_producto;
	echo '<meta http-equiv=refresh content="0.2; '.$url.'">';
	die;
	
	
}

?>