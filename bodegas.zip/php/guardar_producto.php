<?php 


if($_POST){
	
	$conex = mysqli_connect("localhost","root","","empresa");
	
	$nombre_producto = $_POST["nombre_producto"];
	$bodega_producto = $_POST["bodega_producto"];
	
	$sql = "INSERT INTO `producto` (`id_producto`, `nombre_producto`, `id_bodega_fk`, `fecha_ingreso`) VALUES (NULL, '$nombre_producto','$bodega_producto', NOW());";
	$resp = mysqli_query($conex, $sql);
	
	echo "<script> alert('Producto nuevo a sido ingresado con éxito..');</script>";
	
	mysqli_close($conex);
	$url='ingresar_producto.php';
	echo '<meta http-equiv=refresh content="0.2; '.$url.'">';
	die;
	
	
}

?>