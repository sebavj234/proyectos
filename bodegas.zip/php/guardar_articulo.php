<?php 

if($_POST){
	
	$conex = mysqli_connect("localhost","root","","empresa");
	
	$nombre_articulo = $_POST["nombre_articulo"];
	$detalle_articulo = $_POST["detalle_articulo"];
	$producto_articulo = $_POST["producto_articulo"];
	$stock = $_POST["stock_articulo"];
	
	$sql = "INSERT INTO `articulo` (`id_articulo`, `nombre_articulo`, `detalle_articulo`, `id_producto_fk`, `stock_articulo`) VALUES (NULL,'".$nombre_articulo."','".$detalle_articulo."','".$producto_articulo."','".$stock."');";
	$resp = mysqli_query($conex, $sql);
	
	echo "<script> alert('Articulo ingresado con éxito..');</script>";
	
	mysqli_close($conex);
	$url='mantenedor_articulos.php';
	echo '<meta http-equiv=refresh content="0.2; '.$url.'">';
	die;
	
	
}

?>